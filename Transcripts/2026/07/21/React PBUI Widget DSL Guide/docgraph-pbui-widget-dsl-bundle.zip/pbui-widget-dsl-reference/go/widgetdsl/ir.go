package widgetdsl

// These structs are the canonical JSON contract. Keep them free of goja.Value,
// functions, database handles, and host-specific service objects.

type WidgetPage struct {
	Version     string         `json:"version"`
	NodeVersion string         `json:"nodeVersion"`
	ID          string         `json:"id"`
	Title       string         `json:"title"`
	Meta        map[string]any `json:"meta,omitempty"`
	Root        WidgetNode     `json:"root"`
	Shortcuts   []ShortcutSpec `json:"shortcuts,omitempty"`
	PBUI        PbuiManifest   `json:"pbui"`
}

type WidgetNode struct {
	Kind     string         `json:"kind"`
	Text     string         `json:"text,omitempty"`
	Tag      string         `json:"tag,omitempty"`
	Type     string         `json:"type,omitempty"`
	Attrs    map[string]any `json:"attrs,omitempty"`
	Props    map[string]any `json:"props,omitempty"`
	Children []WidgetNode   `json:"children,omitempty"`
}

type PbuiManifest struct {
	PTypes   []PresentationTypeSpec `json:"ptypes"`
	Commands []CommandSpec          `json:"commands"`
}

type PresentationTypeSpec struct {
	Name           string         `json:"name"`
	Label          string         `json:"label"`
	Supertypes     []string       `json:"supertypes"`
	Print          map[string]any `json:"print,omitempty"`
	Parse          map[string]any `json:"parse,omitempty"`
	DescribeFields []string       `json:"describeFields,omitempty"`
}

type CommandArgSpec struct {
	Name      string `json:"name"`
	Kind      string `json:"kind"`
	PType     string `json:"ptype,omitempty"`
	Prompt    string `json:"prompt,omitempty"`
	MinLength int    `json:"minLength,omitempty"`
	Min       any    `json:"min,omitempty"`
	Max       any    `json:"max,omitempty"`
	Integer   bool   `json:"integer,omitempty"`
	Default   any    `json:"default,omitempty"`
}

type CommandSpec struct {
	Name         string           `json:"name"`
	Label        string           `json:"label"`
	Doc          string           `json:"doc,omitempty"`
	Args         []CommandArgSpec `json:"args"`
	DefaultFor   []string         `json:"defaultFor,omitempty"`
	Global       bool             `json:"global,omitempty"`
	DuringAccept bool             `json:"duringAccept,omitempty"`
	When         map[string]any   `json:"when,omitempty"`
	Action       ActionSpec       `json:"action"`
}

type ActionSpec struct {
	Kind    string         `json:"kind"`
	Event   string         `json:"event,omitempty"`
	Name    string         `json:"name,omitempty"`
	To      string         `json:"to,omitempty"`
	Target  string         `json:"target,omitempty"`
	Value   any            `json:"value,omitempty"`
	Detail  map[string]any `json:"detail,omitempty"`
	Payload map[string]any `json:"payload,omitempty"`
	Query   map[string]any `json:"query,omitempty"`
	Replace bool           `json:"replace,omitempty"`
	Confirm string         `json:"confirm,omitempty"`
}

type ShortcutSpec struct {
	ID             string     `json:"id"`
	Key            string     `json:"key"`
	Modifiers      []string   `json:"modifiers,omitempty"`
	Label          string     `json:"label"`
	Action         ActionSpec `json:"action"`
	PreventDefault bool       `json:"preventDefault,omitempty"`
	AllowRepeat    bool       `json:"allowRepeat,omitempty"`
}
