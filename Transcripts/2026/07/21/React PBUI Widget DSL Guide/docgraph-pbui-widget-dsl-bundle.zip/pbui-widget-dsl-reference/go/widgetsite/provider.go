package widgetsite

import (
	"github.com/dop251/goja_nodejs/require"
	"github.com/go-go-golems/go-go-goja/pkg/xgoja/providerapi"
	"your/module/pkg/widgetdsl"
)

const PackageID = "docgraph-widget-site"

func Register(registry *providerapi.ProviderRegistry) error {
	loader := func(moduleName string) func(providerapi.ModuleSetupContext) (require.ModuleLoader, error) {
		return func(providerapi.ModuleSetupContext) (require.ModuleLoader, error) {
			return widgetdsl.NewLoader(moduleName), nil
		}
	}
	return registry.Package(PackageID, providerapi.Module{
		Name:             widgetdsl.ModuleName,
		DefaultAs:        widgetdsl.ModuleName,
		Description:      "Widget IR and PBUI declaration DSL for Docgraph pages.",
		TypeScript:       TypeScriptModule(widgetdsl.ModuleName),
		NewModuleFactory: loader(widgetdsl.ModuleName),
	})
}

// Generate this declaration from the same schema/builder inventory used by Go.
func TypeScriptModule(moduleName string) string {
	return "declare module \"" + moduleName + "\" { /* generated API */ }"
}
