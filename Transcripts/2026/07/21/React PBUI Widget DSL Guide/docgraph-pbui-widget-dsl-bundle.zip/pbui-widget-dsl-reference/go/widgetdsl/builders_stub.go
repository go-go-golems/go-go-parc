package widgetdsl

// This file marks the generated/implemented builder seam. In the real package,
// each method returns the same goja.Object for fluent chaining and writes only
// ordinary Go values. It is intentionally not expanded into hundreds of setters
// in this reference bundle; the textbook guide defines the required behavior.

import "github.com/dop251/goja"

type PageBuilder struct {
	runtime *goja.Runtime
	page    WidgetPage
	object  *goja.Object
}

func NewPageBuilder(runtime *goja.Runtime, title string) *PageBuilder {
	builder := &PageBuilder{runtime: runtime, page: WidgetPage{
		Version: "ggwidget.page/v1", NodeVersion: "ggwidget.node/v1",
		ID: "page", Title: title, PBUI: PbuiManifest{},
	}}
	builder.object = runtime.NewObject()
	// Install id/title/root/section/ptype/command/shortcut/toPage methods here.
	return builder
}

func (builder *PageBuilder) Object() *goja.Object       { return builder.object }
func (builder *PageBuilder) Build() (WidgetPage, error) { return builder.page, nil }

func NewUINamespace(runtime *goja.Runtime) *goja.Object       { return runtime.NewObject() }
func NewPBUINamespace(runtime *goja.Runtime) *goja.Object     { return runtime.NewObject() }
func NewActionNamespace(runtime *goja.Runtime) *goja.Object   { return runtime.NewObject() }
func NewBindingNamespace(runtime *goja.Runtime) *goja.Object  { return runtime.NewObject() }
func NewArgumentNamespace(runtime *goja.Runtime) *goja.Object { return runtime.NewObject() }

// Generate this set from the same component descriptor that generates the
// React registry typings, JSON Schema, help, and golden fixtures.
func GeneratedWidgetTypes() map[string]bool {
	return map[string]bool{
		"Presentation": true, "Text": true, "Caption": true, "CodeText": true,
		"Badge": true, "Button": true, "Stack": true, "Inline": true,
		"Card": true, "Callout": true, "SectionBlock": true, "Metadata": true,
	}
}
