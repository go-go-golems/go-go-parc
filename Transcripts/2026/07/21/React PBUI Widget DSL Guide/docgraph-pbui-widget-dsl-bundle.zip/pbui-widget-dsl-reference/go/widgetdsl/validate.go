package widgetdsl

import (
	"encoding/json"
	"fmt"
	"strings"
)

const (
	maxPTypes    = 256
	maxCommands  = 512
	maxShortcuts = 128
	maxArgs      = 32
	maxNodes     = 10_000
	maxDepth     = 128
)

var allowedTags = map[string]bool{
	"div": true, "span": true, "p": true, "strong": true, "em": true,
	"code": true, "pre": true, "ul": true, "ol": true, "li": true,
}

var forbiddenRawAttrs = map[string]bool{
	"dangerouslysetinnerhtml": true,
	"innerhtml":               true,
	"srcdoc":                  true,
}

var allowedActionKinds = map[string]bool{
	"event": true, "server": true, "navigate": true, "copy": true,
	"openOverlay": true, "closeOverlay": true,
}

func ValidatePage(page WidgetPage, widgetTypes map[string]bool) error {
	// This catches functions, channels, cycles, unsupported map keys, NaN, and
	// other values that cannot cross the JSON boundary.
	if _, err := json.Marshal(page); err != nil {
		return fmt.Errorf("widget page is not JSON serializable: %w", err)
	}
	if page.Version != "ggwidget.page/v1" {
		return fmt.Errorf("unsupported page version %q", page.Version)
	}
	if page.NodeVersion != "ggwidget.node/v1" {
		return fmt.Errorf("unsupported node version %q", page.NodeVersion)
	}
	if strings.TrimSpace(page.ID) == "" || strings.TrimSpace(page.Title) == "" {
		return fmt.Errorf("page id and title are required")
	}
	if len(page.PBUI.PTypes) > maxPTypes {
		return fmt.Errorf("page declares %d ptypes; maximum is %d", len(page.PBUI.PTypes), maxPTypes)
	}
	if len(page.PBUI.Commands) > maxCommands {
		return fmt.Errorf("page declares %d commands; maximum is %d", len(page.PBUI.Commands), maxCommands)
	}
	if len(page.Shortcuts) > maxShortcuts {
		return fmt.Errorf("page declares %d shortcuts; maximum is %d", len(page.Shortcuts), maxShortcuts)
	}

	ptypes, parents, err := validatePTypes(page.PBUI.PTypes)
	if err != nil {
		return err
	}
	if err := validateCommands(page.PBUI.Commands, ptypes); err != nil {
		return err
	}
	if err := validateShortcuts(page.Shortcuts); err != nil {
		return err
	}
	if err := validatePTypeCycles(parents); err != nil {
		return err
	}

	state := nodeValidationState{ids: map[string]bool{}}
	if err := validateNode(page.Root, widgetTypes, 0, &state); err != nil {
		return err
	}
	return nil
}

func validatePTypes(specs []PresentationTypeSpec) (map[string]bool, map[string][]string, error) {
	ptypes := map[string]bool{"any": true, "string": true, "number": true}
	parents := map[string][]string{}
	for _, ptype := range specs {
		if strings.TrimSpace(ptype.Name) == "" || ptypes[ptype.Name] {
			return nil, nil, fmt.Errorf("invalid or duplicate presentation type %q", ptype.Name)
		}
		if strings.TrimSpace(ptype.Label) == "" {
			return nil, nil, fmt.Errorf("presentation type %q has no label", ptype.Name)
		}
		ptypes[ptype.Name] = true
		if len(ptype.Supertypes) == 0 {
			parents[ptype.Name] = []string{"any"}
		} else {
			parents[ptype.Name] = append([]string(nil), ptype.Supertypes...)
		}
	}
	for child, supertypes := range parents {
		seen := map[string]bool{}
		for _, parent := range supertypes {
			if !ptypes[parent] {
				return nil, nil, fmt.Errorf("presentation type %q references unknown supertype %q", child, parent)
			}
			if parent == child {
				return nil, nil, fmt.Errorf("presentation type %q cannot extend itself", child)
			}
			if seen[parent] {
				return nil, nil, fmt.Errorf("presentation type %q repeats supertype %q", child, parent)
			}
			seen[parent] = true
		}
	}
	return ptypes, parents, nil
}

func validatePTypeCycles(parents map[string][]string) error {
	const (
		unseen = iota
		visiting
		done
	)
	state := map[string]int{}
	var visit func(string) error
	visit = func(name string) error {
		switch state[name] {
		case visiting:
			return fmt.Errorf("presentation type cycle includes %q", name)
		case done:
			return nil
		}
		state[name] = visiting
		for _, parent := range parents[name] {
			if _, custom := parents[parent]; custom {
				if err := visit(parent); err != nil {
					return err
				}
			}
		}
		state[name] = done
		return nil
	}
	for name := range parents {
		if err := visit(name); err != nil {
			return err
		}
	}
	return nil
}

func validateCommands(commands []CommandSpec, ptypes map[string]bool) error {
	names := map[string]bool{}
	labels := map[string]bool{}
	for _, command := range commands {
		if strings.TrimSpace(command.Name) == "" || names[command.Name] {
			return fmt.Errorf("invalid or duplicate command name %q", command.Name)
		}
		if strings.TrimSpace(command.Label) == "" || labels[command.Label] {
			return fmt.Errorf("invalid or duplicate command label %q", command.Label)
		}
		names[command.Name] = true
		labels[command.Label] = true
		if len(command.Args) > maxArgs {
			return fmt.Errorf("command %q has %d arguments; maximum is %d", command.Name, len(command.Args), maxArgs)
		}
		argNames := map[string]bool{}
		for _, arg := range command.Args {
			if arg.Name == "" || argNames[arg.Name] {
				return fmt.Errorf("command %q has invalid or duplicate argument %q", command.Name, arg.Name)
			}
			argNames[arg.Name] = true
			switch arg.Kind {
			case "presentation":
				if !ptypes[arg.PType] {
					return fmt.Errorf("command %q references unknown ptype %q", command.Name, arg.PType)
				}
			case "text", "number":
			default:
				return fmt.Errorf("command %q has unsupported argument kind %q", command.Name, arg.Kind)
			}
		}
		for _, ptype := range command.DefaultFor {
			if !ptypes[ptype] {
				return fmt.Errorf("command %q has unknown defaultFor ptype %q", command.Name, ptype)
			}
		}
		if err := validateAction(command.Action); err != nil {
			return fmt.Errorf("command %q: %w", command.Name, err)
		}
	}
	return nil
}

func validateShortcuts(shortcuts []ShortcutSpec) error {
	ids := map[string]bool{}
	chords := map[string]bool{}
	for _, shortcut := range shortcuts {
		if shortcut.ID == "" || ids[shortcut.ID] {
			return fmt.Errorf("invalid or duplicate shortcut id %q", shortcut.ID)
		}
		ids[shortcut.ID] = true
		chord := strings.Join(shortcut.Modifiers, "+") + "+" + strings.ToLower(shortcut.Key)
		if shortcut.Key == "" || chords[chord] {
			return fmt.Errorf("invalid or duplicate shortcut chord %q", chord)
		}
		chords[chord] = true
		if shortcut.Label == "" {
			return fmt.Errorf("shortcut %q has no label", shortcut.ID)
		}
		if err := validateAction(shortcut.Action); err != nil {
			return fmt.Errorf("shortcut %q: %w", shortcut.ID, err)
		}
	}
	return nil
}

func validateAction(action ActionSpec) error {
	if !allowedActionKinds[action.Kind] {
		return fmt.Errorf("unsupported action kind %q", action.Kind)
	}
	switch action.Kind {
	case "event":
		if action.Event == "" {
			return fmt.Errorf("event action requires event")
		}
	case "server":
		if action.Name == "" {
			return fmt.Errorf("server action requires name")
		}
	case "navigate":
		if action.To == "" {
			return fmt.Errorf("navigate action requires to")
		}
	case "openOverlay":
		if action.Target == "" {
			return fmt.Errorf("openOverlay action requires target")
		}
	}
	return nil
}

type nodeValidationState struct {
	count int
	ids   map[string]bool
}

func validateNode(node WidgetNode, widgetTypes map[string]bool, depth int, state *nodeValidationState) error {
	if depth > maxDepth {
		return fmt.Errorf("widget tree exceeds maximum depth %d", maxDepth)
	}
	state.count++
	if state.count > maxNodes {
		return fmt.Errorf("widget tree exceeds maximum node count %d", maxNodes)
	}

	switch node.Kind {
	case "text":
	case "element":
		if !allowedTags[node.Tag] {
			return fmt.Errorf("raw tag %q is not allowed", node.Tag)
		}
		for key := range node.Attrs {
			lower := strings.ToLower(key)
			if strings.HasPrefix(lower, "on") || forbiddenRawAttrs[lower] {
				return fmt.Errorf("raw attribute %q is forbidden", key)
			}
		}
	case "component":
		if node.Type == "" || !widgetTypes[node.Type] {
			return fmt.Errorf("widget type %q is not registered", node.Type)
		}
	default:
		return fmt.Errorf("invalid widget node kind %q", node.Kind)
	}

	if rawID, ok := node.Props["id"]; ok {
		id, ok := rawID.(string)
		if !ok || strings.TrimSpace(id) == "" {
			return fmt.Errorf("widget id must be a non-empty string")
		}
		if state.ids[id] {
			return fmt.Errorf("duplicate widget id %q", id)
		}
		state.ids[id] = true
	}
	for _, child := range node.Children {
		if err := validateNode(child, widgetTypes, depth+1, state); err != nil {
			return err
		}
	}
	return nil
}
