package widgetdsl

import (
	"fmt"

	"github.com/dop251/goja"
	"github.com/dop251/goja_nodejs/require"
)

const ModuleName = "widget.dsl"

// NewLoader exposes one hard-cutover module. Builder callbacks run synchronously
// in the owning goja.Runtime and mutate Go builder state. Build() copies that
// state into the JSON-only structs from ir.go.
func NewLoader(moduleName string) require.ModuleLoader {
	return func(runtime *goja.Runtime, module *goja.Object) {
		exports := runtime.NewObject()
		mustSet(exports, "page", newPageFactory(runtime))
		mustSet(exports, "ui", newUINamespace(runtime))
		mustSet(exports, "pbui", newPBUINamespace(runtime))
		mustSet(exports, "act", newActionNamespace(runtime))
		mustSet(exports, "bind", newBindingNamespace(runtime))
		mustSet(exports, "arg", newArgumentNamespace(runtime))
		mustSet(module, "exports", exports)
	}
}

func newPageFactory(runtime *goja.Runtime) func(goja.FunctionCall) goja.Value {
	return func(call goja.FunctionCall) goja.Value {
		title := call.Argument(0).String()
		builder := newPageBuilder(runtime, title)
		if configure, ok := goja.AssertFunction(call.Argument(1)); ok {
			if _, err := configure(goja.Undefined(), builder.Object()); err != nil {
				panic(runtime.ToValue(err.Error()))
			}
		}
		page, err := builder.Build()
		if err != nil {
			panic(runtime.ToValue(err.Error()))
		}
		if err := ValidatePage(page, GeneratedWidgetTypes()); err != nil {
			panic(runtime.ToValue(err.Error()))
		}
		return runtime.ToValue(page)
	}
}

// The concrete namespace and builder implementations should be generated or
// hand-written as thin setters. They must not retain goja.Value after Build.
func newPageBuilder(runtime *goja.Runtime, title string) *PageBuilder {
	return NewPageBuilder(runtime, title)
}
func newUINamespace(runtime *goja.Runtime) *goja.Object       { return NewUINamespace(runtime) }
func newPBUINamespace(runtime *goja.Runtime) *goja.Object     { return NewPBUINamespace(runtime) }
func newActionNamespace(runtime *goja.Runtime) *goja.Object   { return NewActionNamespace(runtime) }
func newBindingNamespace(runtime *goja.Runtime) *goja.Object  { return NewBindingNamespace(runtime) }
func newArgumentNamespace(runtime *goja.Runtime) *goja.Object { return NewArgumentNamespace(runtime) }

func mustSet(object *goja.Object, name string, value any) {
	if err := object.Set(name, value); err != nil {
		panic(fmt.Errorf("set %s: %w", name, err))
	}
}
