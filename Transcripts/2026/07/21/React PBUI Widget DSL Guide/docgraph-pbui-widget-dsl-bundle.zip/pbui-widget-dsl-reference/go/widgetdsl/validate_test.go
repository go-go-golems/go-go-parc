package widgetdsl

import "testing"

func validPage() WidgetPage {
	return WidgetPage{
		Version: "ggwidget.page/v1", NodeVersion: "ggwidget.node/v1", ID: "demo", Title: "Demo",
		Root: WidgetNode{Kind: "component", Type: "Presentation", Props: map[string]any{"id": "p1"}, Children: []WidgetNode{{Kind: "element", Tag: "strong", Attrs: map[string]any{"className": "title"}, Children: []WidgetNode{{Kind: "text", Text: "D1"}}}}},
		PBUI: PbuiManifest{
			PTypes: []PresentationTypeSpec{{Name: "doc", Label: "Document", Supertypes: []string{"any"}}},
			Commands: []CommandSpec{{Name: "inspect-doc", Label: "Inspect document", Args: []CommandArgSpec{{Name: "doc", Kind: "presentation", PType: "doc"}}, DefaultFor: []string{"doc"}, Action: ActionSpec{Kind: "server", Name: "doc.inspect"}}},
		},
	}
}

func TestValidatePage(t *testing.T) {
	if err := ValidatePage(validPage(), map[string]bool{"Presentation": true}); err != nil { t.Fatal(err) }
}

func TestRejectRawEventAttribute(t *testing.T) {
	page := validPage()
	page.Root = WidgetNode{Kind: "element", Tag: "div", Attrs: map[string]any{"onClick": "evil"}}
	if err := ValidatePage(page, map[string]bool{}); err == nil { t.Fatal("expected error") }
}
