const widget = require("widget.dsl");

const page = widget.page("Docgraph PBUI Workbench", (page) =>
  page
    .id("docgraph-pbui-workbench")
    .ptype("thing", (type) => type.label("Workbench object").supertype("any"))
    .ptype("corpus", (type) => type.label("Corpus").supertype("thing"))
    .ptype("doc", (type) => type.label("Document").supertype("thing"))
    .ptype("recipe", (type) => type.label("Search recipe").supertype("thing"))
    .command("run-recipe", (command) =>
      command
        .label("Run recipe against…")
        .argument("recipe", widget.arg.presentation("recipe"))
        .argument("corpus", widget.arg.presentation("corpus"))
        .defaultFor("recipe")
        .action(widget.act.server("docgraph.runRecipe", {
          recipeId: widget.bind.arg("recipe"),
          corpusId: widget.bind.arg("corpus"),
        })),
    )
    .section("Recipes", (section) =>
      section.view(
        widget.pbui.presentation(
          "recipe",
          { kind: "recipe", id: "acme:debug-search/v1" },
          "acme:debug-search/v1",
          widget.ui.card(
            { title: "acme:debug-search/v1" },
            widget.ui.code("parse → retrieve → fuse → expand → limit"),
          ),
        ),
      ),
    ),
);

module.exports = page;
