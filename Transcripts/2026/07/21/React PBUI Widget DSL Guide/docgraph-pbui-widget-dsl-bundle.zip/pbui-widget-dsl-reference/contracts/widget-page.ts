/** Language-independent contract shared by Go, Goja, JSON Schema, and React. */
export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | JsonObject;
export interface JsonObject { [key: string]: JsonValue }

export interface TextNode {
  kind: "text";
  text: string;
}

export interface ElementNode {
  kind: "element";
  tag: "div" | "span" | "p" | "strong" | "em" | "code" | "pre" | "ul" | "ol" | "li";
  attrs?: JsonObject;
  children?: WidgetNode[];
}

export interface ComponentNode {
  kind: "component";
  type: string;
  props?: JsonObject;
  children?: WidgetNode[];
}

export type WidgetNode = TextNode | ElementNode | ComponentNode;

export type BindingSpec =
  | { kind: "binding"; source: "arg"; name: string; path?: string }
  | { kind: "binding"; source: "context"; path: string }
  | { kind: "binding"; source: "field"; path: string }
  | { kind: "binding"; source: "const"; value: JsonValue }
  | { kind: "binding"; source: "template"; template: string };

export type BindableValue = JsonValue | BindingSpec | BindableValue[] | { [key: string]: BindableValue };

export interface ActionBase { confirm?: string }
export type ActionSpec =
  | (ActionBase & { kind: "event"; event: string; detail?: Record<string, BindableValue> })
  | (ActionBase & { kind: "server"; name: string; payload?: Record<string, BindableValue> })
  | (ActionBase & { kind: "navigate"; to: string; replace?: boolean; query?: Record<string, BindableValue> })
  | (ActionBase & { kind: "copy"; value: BindableValue })
  | (ActionBase & { kind: "openOverlay"; target?: string })
  | (ActionBase & { kind: "closeOverlay"; target?: string });

export type PrintCodecSpec =
  | { kind: "field"; field: string; prefix?: string; suffix?: string }
  | { kind: "template"; template: string }
  | { kind: "literal"; value: string };

export type ParseCodecSpec =
  | { kind: "entityLookup"; entityKind: string; fields: string[]; match: "exact" | "prefix" }
  | { kind: "enum"; values: string[]; caseSensitive?: boolean }
  | { kind: "disabled" };

export interface PresentationTypeSpec {
  name: string;
  label: string;
  supertypes: string[];
  print?: PrintCodecSpec;
  parse?: ParseCodecSpec;
  describeFields?: string[];
}

export type WhenExpr =
  | { kind: "true" }
  | { kind: "fieldEquals" | "fieldNotEquals"; path: string; value: JsonValue }
  | { kind: "and"; terms: WhenExpr[] }
  | { kind: "or"; terms: WhenExpr[] }
  | { kind: "not"; term: WhenExpr };

export type CommandArgSpec =
  | { name: string; kind: "presentation"; ptype: string; prompt?: string }
  | { name: string; kind: "text"; prompt?: string; minLength?: number; default?: string }
  | { name: string; kind: "number"; prompt?: string; min?: number; max?: number; integer?: boolean; default?: number };

export interface PresentationCommandSpec {
  name: string;
  label: string;
  doc?: string;
  args: CommandArgSpec[];
  defaultFor?: string[];
  global?: boolean;
  duringAccept?: boolean;
  when?: WhenExpr;
  action: ActionSpec;
}

export interface ShortcutSpec {
  id: string;
  key: string;
  modifiers?: Array<"Alt" | "Control" | "Meta" | "Shift">;
  label: string;
  action: ActionSpec;
  preventDefault?: boolean;
  allowRepeat?: boolean;
}

export interface PbuiManifest {
  ptypes: PresentationTypeSpec[];
  commands: PresentationCommandSpec[];
}

export interface WidgetPage {
  version: "ggwidget.page/v1";
  nodeVersion: "ggwidget.node/v1";
  id: string;
  title: string;
  meta?: JsonObject;
  root: WidgetNode;
  shortcuts?: ShortcutSpec[];
  pbui: PbuiManifest;
}

export interface EntityRecord {
  kind: string;
  id: string;
  revision?: string;
  value: JsonObject;
}

export interface WidgetPageResponse {
  page: WidgetPage;
  entities: EntityRecord[];
  revision: string;
  etag?: string;
}

export interface WidgetActionRequest {
  pageId: string;
  pageRevision: string;
  command?: string;
  action: ActionSpec;
  args: JsonObject;
  seed?: { ptype: string; ref: { kind: string; id: string } };
  idempotencyKey: string;
}

export interface WidgetActionResult {
  ok: boolean;
  refresh?: boolean;
  patch?: JsonObject;
  toast?: string;
  error?: string;
  undo?: ActionSpec;
  nextRevision?: string;
}
