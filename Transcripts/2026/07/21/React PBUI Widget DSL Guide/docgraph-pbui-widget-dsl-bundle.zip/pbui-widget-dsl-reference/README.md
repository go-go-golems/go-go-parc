# PBUI Widget DSL reference layout

This directory is the production-oriented companion to `docgraph-workbench-pbui.jsx`.
The JSX file is a runnable, self-contained demonstrator. This directory shows where
its responsibilities should live in a real go-go-goja + React repository.

It is an integration blueprint rather than a standalone application. The Go files
expect the repository's existing `go-go-goja`, `goja`, and provider packages. The
React files expect `@go-go-golems/pbui-core`, `@go-go-golems/pbui-react`,
`@go-go-golems/pbui-listener`, `@go-go-golems/pbui-chrome`, and the project's
stable design-system components.

The invariant across every file is:

> Goja configuration callbacks execute while authoring the page. Only versioned,
> JSON-compatible Widget IR, presentation declarations, commands, bindings, and
> actions cross into the browser.

## Directory map

- `contracts/` — the language-independent page envelope and JSON Schema.
- `go/widgetdsl/` — Go values, validation, and the `widget.dsl` Goja module loader.
- `go/widgetsite/` — provider registration in go-go-goja.
- `react/src/widgets/` — registry-driven Widget IR rendering and central actions.
- `react/src/pbui/` — entity resolver, manifest-to-PBUI compiler, and presentation adapter.
- `react/src/app/` — backend-connected container; reusable components stay API-free.
- `examples/` — a page script authored with `require("widget.dsl")`.
- `tests/` — contract and integration coverage matrix.

## Important contract decisions represented here

- Raw elements use a finite tag list and reject DOM event or HTML-injection attributes.
- Unknown widgets and duplicate adapters fail visibly; registries never use last-write-wins.
- Remote PBUI commands compile into local `CommandTable` definitions. Presentation
  arguments remain typed reference envelopes, while text and number arguments become
  immediate values.
- `bind.arg(name)` resolves a presentation argument to `ref.id`; an explicit path such
  as `bind.arg(name, "ref")` accesses richer metadata.
- Server actions carry page revision, stable command id, collected argument references,
  the resolved action payload, and an idempotency key.
- The host includes PBUI chrome and a listener so output records can remain live
  presentations rather than becoming inert logging text.

## What is intentionally incomplete

`builders_stub.go` marks the generated/implemented fluent-builder seam. The actual
setter inventory should be generated from the same descriptor that produces the
TypeScript declarations, JSON Schema, help pages, and golden examples. The placeholder
module import in `go/widgetsite/provider.go` must be replaced with the repository's
real module path.

Read the accompanying textbook guide before treating these files as an implementation
checklist. Remote/server undo, revision conflict policy, asynchronous entity hydration,
component vocabulary, and plugin trust remain explicit product decisions.
