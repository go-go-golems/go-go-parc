# Contract test matrix

| Layer | Test | Required assertion |
|---|---|---|
| Go builder | Golden JSON | A script produces byte-stable normalized `WidgetPage` JSON. |
| Go builder | Callback lifetime | No `goja.Value`, function, runtime, or host service is reachable from the built page. |
| Go compiler | Validate before clone | A function-valued prop fails explicitly; serialization never silently drops it. |
| Go validator | Allowlist and budgets | Unknown widgets, raw tags, DOM event/HTML-injection attributes, action kinds, duplicate ids, cycles, excessive depth, and node-budget overflow fail explicitly. |
| Schema | Cross-language fixture | Go JSON validates against the checked-in Draft 2020-12 schema and TypeScript decodes it. |
| Schema | Unsafe raw attribute | An `onClick`, `srcDoc`, or `dangerouslySetInnerHTML` attribute is rejected. |
| React registry | Duplicate type | Registry creation fails rather than replacing the first adapter. |
| React renderer | Unknown type | The page remains mounted and renders a visible diagnostic. |
| React renderer | Defense in depth | Unsafe raw attributes render a diagnostic even when upstream validation was bypassed. |
| PBUI compiler | Type lattice | A subtype presentation satisfies an argument requesting its supertype. |
| PBUI compiler | Built-in ptypes | The manifest compiler never tries to redefine reserved `any`, `string`, or `number` ptypes. |
| PBUI compiler | Menu applicability | `when` expressions are pure, deterministic, and state-sensitive. |
| PBUI compiler | Accept loop | Seeded first argument plus clicked second argument dispatches one action with both typed reference envelopes. |
| PBUI accessibility | Keyboard parity | Enter, menu key, describe key, Escape, and page shortcuts match pointer behavior. |
| Action transport | Argument normalization | Presentation arguments retain `{ptype, ref, label}`; typed values remain scalars. |
| Action transport | Binding resolution | `bind.arg(name)` resolves an entity id, explicit paths resolve richer metadata, and row/context bindings use only permitted paths. |
| Action transport | Resolved server payload | The request contains no unresolved binding descriptors in the server action payload. |
| Action transport | Stale revision | Server rejects or rebases a request against an obsolete page/entity revision. |
| E2E | Rendering is registering | A DOC rendered in two unrelated components receives the same computed commands. |
| E2E | Live output | A DOC printed in the PBUI listener remains a command target. |
| E2E | Stale object | Removing an entity makes old listener/presentation refs fail through the resolver, not inside command bodies. |
