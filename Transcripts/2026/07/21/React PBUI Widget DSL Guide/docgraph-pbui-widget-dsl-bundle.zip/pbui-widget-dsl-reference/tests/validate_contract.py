"""Run with: python tests/validate_contract.py

Requires jsonschema. This checks the committed cross-language fixture and proves
that raw event attributes are rejected by the Draft 2020-12 contract.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = json.loads((ROOT / "contracts/widget-page.schema.json").read_text())
FIXTURE = json.loads((ROOT / "contracts/widget-page.example.json").read_text())

validator = Draft202012Validator(SCHEMA)
errors = list(validator.iter_errors(FIXTURE))
if errors:
    raise SystemExit("valid fixture failed: " + "; ".join(error.message for error in errors))

unsafe = copy.deepcopy(FIXTURE)
unsafe["root"]["children"][0]["attrs"]["onClick"] = "not allowed"
if not list(validator.iter_errors(unsafe)):
    raise SystemExit("unsafe raw event attribute unexpectedly validated")

print("WidgetPage fixture validates; unsafe raw attribute is rejected.")
