import { Fragment, createElement, type ReactNode } from "react";
import type { ComponentNode, WidgetNode } from "../../../contracts/widget-page";
import type { ActionContext, WidgetActionHandler } from "./actions";
import type { RenderContext, WidgetRegistry } from "./registry";

export interface WidgetRendererProps {
  node: WidgetNode;
  registry: WidgetRegistry;
  onAction: WidgetActionHandler;
  actionContext: ActionContext;
}

export function WidgetRenderer(props: WidgetRendererProps) {
  const context = createRenderContext(props.registry, props.onAction, props.actionContext);
  return <>{renderNode(props.node, props.registry, context)}</>;
}

function createRenderContext(registry: WidgetRegistry, onAction: WidgetActionHandler, actionContext: ActionContext): RenderContext {
  const context: RenderContext = {
    renderNode: (node) => renderNode(node, registry, context),
    renderChildren: (children = []) => children.map((child, index) => (
      <Fragment key={nodeKey(child, index)}>{renderNode(child, registry, context)}</Fragment>
    )),
    dispatchAction: (action, localContext) => onAction(action, { ...actionContext, ...localContext }),
  };
  return context;
}

function renderNode(node: WidgetNode, registry: WidgetRegistry, context: RenderContext): ReactNode {
  if (node.kind === "text") return node.text;
  if (node.kind === "element") {
    const checked = safeElementAttrs(node.attrs ?? {});
    if (!checked.ok) return <div role="alert">Unsafe raw element attribute <code>{checked.attribute}</code></div>;
    return createElement(node.tag, checked.attrs, context.renderChildren(node.children));
  }
  return renderComponent(node, registry, context);
}

function safeElementAttrs(attrs: Record<string, unknown>):
  | { ok: true; attrs: Record<string, unknown> }
  | { ok: false; attribute: string } {
  for (const key of Object.keys(attrs)) {
    if (/^on/i.test(key) || ["dangerouslySetInnerHTML", "innerHTML", "srcDoc", "srcdoc"].includes(key)) {
      return { ok: false, attribute: key };
    }
  }
  return { ok: true, attrs };
}

function renderComponent(node: ComponentNode, registry: WidgetRegistry, context: RenderContext): ReactNode {
  const adapter = registry.get(node.type);
  if (!adapter) return <div role="alert">Unknown widget type <code>{node.type}</code></div>;
  return adapter.render(node.props ?? {}, context.renderChildren(node.children), context, node);
}

function nodeKey(node: WidgetNode, index: number): string | number {
  if (node.kind === "component" && typeof node.props?.id === "string") return node.props.id;
  return node.kind === "component" ? `${node.type}-${index}` : index;
}
