import type { ReactNode } from "react";
import { Presentation } from "@go-go-golems/pbui-react";
import { defineWidget } from "../widgets/registry";

interface PresentationProps {
  ptype: string;
  ref: { kind: string; id: string };
  label: string;
  quiet?: boolean;
  duringAccept?: "gated" | "active" | "fallthrough";
  disabled?: boolean;
}

export const presentationAdapter = defineWidget<PresentationProps>({
  type: "Presentation",
  render(props, children: ReactNode[]) {
    return (
      <Presentation
        type={props.ptype}
        object={props.ref}
        label={props.label}
        quiet={props.quiet}
        duringAccept={props.duringAccept}
        disabled={props.disabled}
      >
        {children}
      </Presentation>
    );
  },
});
