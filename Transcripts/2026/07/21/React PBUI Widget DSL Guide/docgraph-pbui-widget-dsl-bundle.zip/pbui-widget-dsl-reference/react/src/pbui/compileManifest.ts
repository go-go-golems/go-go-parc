/*
 * Compiler from a trusted, validated serializable PBUI manifest into the local
 * @go-go-golems/pbui-core engine. The wire format stays dynamic; this module is
 * the narrow translation boundary that turns it into concrete PBUI specs.
 */
import {
  CommandTable,
  PbuiEngine,
  PTypes,
  defineBuiltinPtypes,
  installUndoCommands,
  valueRef,
  type ArgSpec,
  type ArgValue,
  type ArgValues,
  type Resolver,
} from "@go-go-golems/pbui-core";
import type {
  CommandArgSpec,
  JsonObject,
  PbuiManifest,
  PresentationCommandSpec,
  PresentationTypeSpec,
  WidgetPage,
} from "../../../contracts/widget-page";
import type { ActionContext, WidgetActionHandler } from "../widgets/actions";
import { EntityStore, type ObjectRef } from "./entityStore";

export interface WidgetWorld {
  entities: EntityStore;
  page: WidgetPage;
  pageRevision: string;
  dispatchAction: WidgetActionHandler;
}

export function compileWidgetPageEngine(world: WidgetWorld): PbuiEngine<WidgetWorld> {
  const ptypes = new PTypes<WidgetWorld>();
  defineBuiltinPtypes(ptypes);
  installPresentationTypes(ptypes, world.page.pbui, world.entities);

  const commands = new CommandTable<WidgetWorld>();
  installCommands(commands, world.page.pbui, world);

  const resolver: Resolver = {
    resolve: (ref) => {
      if ("value" in ref) return ref.value;
      return world.entities.resolve(ref as ObjectRef);
    },
  };
  const engine = new PbuiEngine({
    ptypes,
    commands,
    resolver,
    world,
    idleDoc: "L/Enter: default command; M: menu; D: describe; right-click: applicable commands.",
  });
  installUndoCommands(engine);
  return engine;
}

function installPresentationTypes(
  ptypes: PTypes<WidgetWorld>,
  manifest: PbuiManifest,
  entities: EntityStore,
): void {
  for (const spec of topologicalPtypes(manifest.ptypes)) {
    ptypes.define<Record<string, unknown>>({
      name: spec.name,
      supertypes: spec.supertypes.length ? spec.supertypes : ["any"],
      print: (value) => printValue(spec, value),
      describe: (value) => (spec.describeFields ?? []).map((field) => ({
        t: "text" as const,
        s: `${field}: ${String(value[field] ?? "")}`,
      })),
      parse: (text) => parseValue(spec, text, entities),
    });
  }
}

function installCommands(
  commands: CommandTable<WidgetWorld>,
  manifest: PbuiManifest,
  world: WidgetWorld,
): void {
  for (const declaration of manifest.commands) {
    const args = declaration.args.map(compileArg);
    commands.define({
      // PBUI currently has one user-visible command name. Keep labels unique;
      // the stable wire id remains declaration.name in ActionContext.command.
      name: declaration.label || declaration.name,
      doc: declaration.doc,
      args,
      isDefaultFor: declaration.defaultFor,
      global: declaration.global,
      duringAccept: declaration.duringAccept,
      appliesTo: declaration.when
        ? (presentation, _world, resolve) => {
            const value = resolve?.(presentation.ref);
            return value !== undefined && evaluateWhen(declaration.when, value);
          }
        : undefined,
      run: async (collected) => {
        const actionArgs = normalizeArgValues(declaration, collected);
        const context: ActionContext = {
          pageId: world.page.id,
          pageRevision: world.pageRevision,
          command: declaration.name,
          args: actionArgs,
          seed: firstPresentationSeed(declaration, collected),
        };
        await world.dispatchAction(declaration.action, context);
      },
    });
  }
}

function compileArg(input: CommandArgSpec): ArgSpec {
  if (input.kind === "presentation") {
    return { name: input.name, type: input.ptype, prompt: input.prompt };
  }

  if (input.kind === "text") {
    const spec: ArgSpec = {
      name: input.name,
      type: "string",
      input: "typed",
      prompt: input.prompt,
    };
    if (input.default !== undefined) {
      spec.default = () => ({
        type: "string",
        ref: valueRef(input.default as string),
        label: input.default as string,
      });
    }
    if (input.minLength !== undefined) {
      spec.validate = (value) => {
        const text = valueRefValue(value);
        return String(text ?? "").length >= input.minLength!
          ? true
          : `${input.name} must contain at least ${input.minLength} characters`;
      };
    }
    return spec;
  }

  const spec: ArgSpec = {
    name: input.name,
    type: "number",
    input: "typed",
    prompt: input.prompt,
  };
  if (input.default !== undefined) {
    spec.default = () => ({
      type: "number",
      ref: valueRef(input.default as number),
      label: String(input.default),
    });
  }
  if (input.min !== undefined || input.max !== undefined || input.integer) {
    spec.validate = (value) => {
      const number = Number(valueRefValue(value));
      if (input.integer && !Number.isInteger(number)) return `${input.name} must be an integer`;
      if (input.min !== undefined && number < input.min) return `${input.name} must be at least ${input.min}`;
      if (input.max !== undefined && number > input.max) return `${input.name} must be at most ${input.max}`;
      return true;
    };
  }
  return spec;
}

function valueRefValue(value: ArgValue): unknown {
  return "value" in value.ref ? value.ref.value : undefined;
}

function normalizeArgValues(
  declaration: PresentationCommandSpec,
  values: ArgValues,
): JsonObject {
  const output: JsonObject = {};
  for (const input of declaration.args) {
    const value = values[input.name];
    if (!value) continue;
    if ("value" in value.ref) {
      output[input.name] = toJson(value.ref.value);
    } else {
      output[input.name] = {
        ptype: value.type,
        ref: { kind: value.ref.kind, id: value.ref.id },
        label: value.label,
      };
    }
  }
  return output;
}

function firstPresentationSeed(
  declaration: PresentationCommandSpec,
  values: ArgValues,
): ActionContext["seed"] {
  const first = declaration.args.find((input) => input.kind === "presentation");
  if (!first) return undefined;
  const value = values[first.name];
  if (!value || "value" in value.ref) return undefined;
  return { ptype: value.type, ref: { kind: value.ref.kind, id: value.ref.id } };
}

function toJson(value: unknown): import("../../../contracts/widget-page").JsonValue {
  if (value === null || value === undefined) return null;
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return value;
  if (Array.isArray(value)) return value.map(toJson);
  if (typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([key, child]) => [key, toJson(child)]),
    );
  }
  return String(value);
}

function printValue(spec: PresentationTypeSpec, value: Record<string, unknown>): string {
  if (!spec.print) return `#<${spec.name.toUpperCase()}>`;
  if (spec.print.kind === "literal") return spec.print.value;
  if (spec.print.kind === "field") {
    return `${spec.print.prefix ?? ""}${String(value[spec.print.field] ?? "")}${spec.print.suffix ?? ""}`;
  }
  return spec.print.template.replace(
    /\$\{([^}]+)\}/g,
    (_, field: string) => String(value[field] ?? ""),
  );
}

function parseValue(spec: PresentationTypeSpec, text: string, entities: EntityStore) {
  const parse = spec.parse;
  if (!parse || parse.kind === "disabled") {
    return { ok: false as const, err: `${spec.label} cannot be entered as text` };
  }
  if (parse.kind === "enum") {
    const found = parse.values.find((candidate) => (
      parse.caseSensitive ? candidate === text : candidate.toLowerCase() === text.toLowerCase()
    ));
    return found
      ? { ok: true as const, value: found, ref: valueRef(found), label: found }
      : { ok: false as const, err: `${text} is not a ${spec.label}` };
  }

  const needle = text.trim().toLowerCase();
  const matches = entities.list(parse.entityKind).filter((record) => parse.fields.some((field) => {
    const candidate = String(record.value[field] ?? "").toLowerCase();
    return parse.match === "exact" ? candidate === needle : candidate.startsWith(needle);
  }));
  if (matches.length !== 1) {
    return {
      ok: false as const,
      err: matches.length ? `${text} is ambiguous` : `${text} does not name a ${spec.label}`,
    };
  }
  const match = matches[0]!;
  return {
    ok: true as const,
    value: match.value,
    ref: { kind: match.kind, id: match.id },
    label: match.id,
  };
}

function evaluateWhen(expression: PresentationCommandSpec["when"], value: unknown): boolean {
  if (!expression || expression.kind === "true") return true;
  if (expression.kind === "and") return expression.terms.every((term) => evaluateWhen(term, value));
  if (expression.kind === "or") return expression.terms.some((term) => evaluateWhen(term, value));
  if (expression.kind === "not") return !evaluateWhen(expression.term, value);
  const actual = expression.path.split(".").filter(Boolean).reduce<unknown>(
    (current, part) => current && typeof current === "object"
      ? (current as Record<string, unknown>)[part]
      : undefined,
    value,
  );
  return expression.kind === "fieldEquals" ? actual === expression.value : actual !== expression.value;
}

function topologicalPtypes(specs: PresentationTypeSpec[]): PresentationTypeSpec[] {
  const builtins = new Set(["any", "number", "string"]);
  const custom = specs.filter((spec) => !builtins.has(spec.name));
  const remaining = new Map(custom.map((spec) => [spec.name, spec]));
  const emitted = new Set(builtins);
  const output: PresentationTypeSpec[] = [];

  for (const spec of custom) {
    for (const parent of spec.supertypes) {
      if (!emitted.has(parent) && !remaining.has(parent)) {
        throw new Error(`Unknown supertype ${parent} of ${spec.name}`);
      }
    }
  }

  while (remaining.size) {
    const ready = [...remaining.values()].filter((spec) => (
      spec.supertypes.every((parent) => emitted.has(parent))
    ));
    if (!ready.length) {
      throw new Error(`Presentation type cycle: ${[...remaining.keys()].join(", ")}`);
    }
    for (const spec of ready) {
      output.push(spec);
      emitted.add(spec.name);
      remaining.delete(spec.name);
    }
  }
  return output;
}
