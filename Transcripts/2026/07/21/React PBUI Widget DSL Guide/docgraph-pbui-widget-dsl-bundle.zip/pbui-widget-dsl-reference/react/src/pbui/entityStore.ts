import type { EntityRecord, JsonObject } from "../../../contracts/widget-page";

export interface ObjectRef { kind: string; id: string }

export class EntityStore {
  private readonly records = new Map<string, EntityRecord>();

  constructor(records: EntityRecord[] = []) {
    this.replace(records);
  }

  replace(records: EntityRecord[]): void {
    this.records.clear();
    for (const record of records) this.records.set(this.key(record), record);
  }

  upsert(records: EntityRecord[]): void {
    for (const record of records) this.records.set(this.key(record), record);
  }

  resolve(ref: ObjectRef): JsonObject | undefined {
    return this.records.get(this.key(ref))?.value;
  }

  list(kind: string): EntityRecord[] {
    return [...this.records.values()].filter((record) => record.kind === kind);
  }

  private key(ref: ObjectRef): string {
    return `${ref.kind}:${ref.id}`;
  }
}
