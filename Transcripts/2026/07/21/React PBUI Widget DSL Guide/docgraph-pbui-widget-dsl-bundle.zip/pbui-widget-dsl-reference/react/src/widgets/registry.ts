import type { ReactNode } from "react";
import type { ComponentNode, WidgetNode } from "../../../contracts/widget-page";
import type { WidgetActionHandler } from "./actions";

export interface RenderContext {
  renderNode(node: WidgetNode): ReactNode;
  renderChildren(children?: WidgetNode[]): ReactNode[];
  dispatchAction: WidgetActionHandler;
}

export interface WidgetAdapter<P = Record<string, unknown>> {
  type: string;
  render(props: P, children: ReactNode[], context: RenderContext, node: ComponentNode): ReactNode;
}

export interface WidgetRegistry {
  get(type: string): WidgetAdapter | undefined;
  entries(): WidgetAdapter[];
}

export function defineWidget<P>(adapter: WidgetAdapter<P>): WidgetAdapter<P> {
  return adapter;
}

export function createWidgetRegistry(adapters: readonly WidgetAdapter[]): WidgetRegistry {
  const byType = new Map<string, WidgetAdapter>();
  for (const adapter of adapters) {
    if (byType.has(adapter.type)) throw new Error(`Duplicate widget adapter: ${adapter.type}`);
    byType.set(adapter.type, adapter);
  }
  return { get: (type) => byType.get(type), entries: () => [...byType.values()] };
}

export function mergeWidgetRegistries(...registries: WidgetRegistry[]): WidgetRegistry {
  return createWidgetRegistry(registries.flatMap((registry) => registry.entries()));
}
