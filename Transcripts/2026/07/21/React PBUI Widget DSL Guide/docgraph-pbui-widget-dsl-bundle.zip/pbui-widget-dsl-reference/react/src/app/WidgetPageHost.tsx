import { useMemo } from "react";
import { PbuiProvider, usePbuiSurface } from "@go-go-golems/pbui-react";
import { ContextMenuHost, MouseDocBar, StatusLine } from "@go-go-golems/pbui-chrome";
import { Listener } from "@go-go-golems/pbui-listener";
import type { WidgetPageResponse } from "../../../contracts/widget-page";
import { EntityStore } from "../pbui/entityStore";
import { compileWidgetPageEngine } from "../pbui/compileManifest";
import { WidgetRenderer } from "../widgets/WidgetRenderer";
import type { WidgetRegistry } from "../widgets/registry";
import type { WidgetActionHandler } from "../widgets/actions";

export function WidgetPageHost(props: {
  response: WidgetPageResponse;
  registry: WidgetRegistry;
  onAction: WidgetActionHandler;
}) {
  const runtime = useMemo(() => {
    const entities = new EntityStore(props.response.entities);
    const world = {
      entities,
      page: props.response.page,
      pageRevision: props.response.revision,
      dispatchAction: props.onAction,
    };
    return { world, engine: compileWidgetPageEngine(world) };
  }, [props.response, props.onAction]);

  return (
    <PbuiProvider engine={runtime.engine}>
      <PageSurface response={props.response} registry={props.registry} onAction={props.onAction} />
    </PbuiProvider>
  );
}

function PageSurface(props: {
  response: WidgetPageResponse;
  registry: WidgetRegistry;
  onAction: WidgetActionHandler;
}) {
  const surface = usePbuiSurface();
  return (
    <div className="pbui-root" {...surface}>
      <main data-widget-page-id={props.response.page.id}>
        <WidgetRenderer
          node={props.response.page.root}
          registry={props.registry}
          onAction={props.onAction}
          actionContext={{ pageId: props.response.page.id, pageRevision: props.response.revision }}
        />
      </main>
      <aside aria-label="Command listener" data-widget-listener>
        <Listener prompt="WIDGET> " />
      </aside>
      <ContextMenuHost />
      <MouseDocBar />
      <StatusLine />
    </div>
  );
}
