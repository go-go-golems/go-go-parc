import type {
  ActionSpec,
  BindableValue,
  BindingSpec,
  JsonObject,
  JsonValue,
  WidgetActionRequest,
  WidgetActionResult,
} from "../../../contracts/widget-page";

export interface ActionContext {
  pageId: string;
  pageRevision: string;
  command?: string;
  /**
   * Typed values are scalars. Presentation values are envelopes containing
   * { ptype, ref, label }. bind.arg(name) returns ref.id for such an envelope;
   * bind.arg(name, "ref") or bind.arg(name, "label") can request more detail.
   */
  args?: Record<string, unknown>;
  seed?: { ptype: string; ref: { kind: string; id: string } };
  row?: JsonObject;
  componentType?: string;
  [key: string]: unknown;
}

export type WidgetActionHandler = (
  action: ActionSpec,
  context: ActionContext,
) => void | Promise<void>;

function lookup(root: unknown, path = ""): unknown {
  let value = root;
  for (const part of path.split(".").filter(Boolean)) {
    if (!value || typeof value !== "object") return undefined;
    value = (value as Record<string, unknown>)[part];
  }
  return value;
}

function isBinding(value: unknown): value is BindingSpec {
  return Boolean(
    value &&
      typeof value === "object" &&
      (value as { kind?: string }).kind === "binding",
  );
}

function isPresentationArgument(value: unknown): value is {
  ptype: string;
  ref: { kind: string; id: string };
  label: string;
} {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Record<string, unknown>;
  const ref = candidate.ref;
  return Boolean(
    typeof candidate.ptype === "string" &&
      ref &&
      typeof ref === "object" &&
      typeof (ref as Record<string, unknown>).kind === "string" &&
      typeof (ref as Record<string, unknown>).id === "string",
  );
}

export function resolveBindable(value: BindableValue, context: ActionContext): JsonValue {
  if (Array.isArray(value)) return value.map((child) => resolveBindable(child, context));
  if (isBinding(value)) {
    if (value.source === "const") return value.value;
    if (value.source === "arg") {
      const argument = context.args?.[value.name];
      if (value.path) return toJson(lookup(argument, value.path));
      // The common command payload needs the selected entity id, not a live
      // browser object. More detail remains available through an explicit path.
      if (isPresentationArgument(argument)) return argument.ref.id;
      return toJson(argument);
    }
    if (value.source === "context") return toJson(lookup(context, value.path));
    if (value.source === "field") return toJson(lookup(context.row, value.path));
    if (value.source === "template") return renderTemplate(value.template, context);
    return null;
  }
  if (value && typeof value === "object") {
    const out: JsonObject = {};
    for (const [key, child] of Object.entries(value)) {
      out[key] = resolveBindable(child as BindableValue, context);
    }
    return out;
  }
  return value;
}

function toJson(value: unknown): JsonValue {
  if (value === null || value === undefined) return null;
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    return value;
  }
  if (Array.isArray(value)) return value.map(toJson);
  if (typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).map(([key, child]) => [key, toJson(child)]),
    );
  }
  return String(value);
}

function renderTemplate(template: string, context: ActionContext): string {
  return template.replace(
    /\$\{([^}]+)\}/g,
    (_, path: string) => String(lookup(context, path) ?? ""),
  );
}

function resolveObject(
  value: Record<string, BindableValue> | undefined,
  context: ActionContext,
): JsonObject {
  return resolveBindable(value ?? {}, context) as JsonObject;
}

export function createActionDispatcher(options: {
  endpoint: string;
  onEvent?: (event: string, detail: JsonObject, context: ActionContext) => void;
  onResult?: (result: WidgetActionResult) => void;
}): WidgetActionHandler {
  return async (action, context) => {
    if (action.confirm && !window.confirm(renderTemplate(action.confirm, context))) return;

    if (action.kind === "event") {
      const detail = resolveObject(action.detail, context);
      if (options.onEvent) options.onEvent(action.event, detail, context);
      else window.dispatchEvent(new CustomEvent(action.event, { detail: { ...detail, context } }));
      return;
    }

    if (action.kind === "copy") {
      await navigator.clipboard.writeText(String(resolveBindable(action.value, context) ?? ""));
      return;
    }

    if (action.kind === "navigate") {
      const target = new URL(renderTemplate(action.to, context), window.location.href);
      for (const [name, bindable] of Object.entries(action.query ?? {})) {
        const resolved = resolveBindable(bindable, context);
        const values = Array.isArray(resolved) ? resolved : [resolved];
        target.searchParams.delete(name);
        for (const item of values) {
          if (item !== null && typeof item !== "object") target.searchParams.append(name, String(item));
        }
      }
      const method = action.replace ? "replaceState" : "pushState";
      window.history[method]({}, "", `${target.pathname}${target.search}${target.hash}`);
      window.dispatchEvent(new PopStateEvent("popstate"));
      return;
    }

    if (action.kind === "openOverlay" || action.kind === "closeOverlay") {
      window.dispatchEvent(new CustomEvent("widget:overlay", { detail: { action, context } }));
      return;
    }

    if (action.kind !== "server") return;
    const resolvedAction: ActionSpec = {
      ...action,
      payload: resolveObject(action.payload, context),
    };
    const request: WidgetActionRequest = {
      pageId: context.pageId,
      pageRevision: context.pageRevision,
      command: context.command,
      action: resolvedAction,
      args: toJson(context.args ?? {}) as JsonObject,
      seed: context.seed,
      idempotencyKey: crypto.randomUUID(),
    };
    const response = await fetch(`${options.endpoint}/${encodeURIComponent(action.name)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request),
    });
    const result = (await response.json().catch(() => ({
      ok: false,
      error: `Action ${action.name} returned invalid JSON`,
    }))) as WidgetActionResult;
    options.onResult?.(result);
    if (!response.ok || result.ok === false) {
      throw new Error(result.error || `Action ${action.name} failed`);
    }
  };
}
